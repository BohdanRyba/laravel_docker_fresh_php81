Nova.booting((Vue, router, store) => {
  Vue.component('{{ component }}', require('./components/Tool'))
})
